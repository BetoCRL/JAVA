#!/bin/bash

# For the input file sample.txt, extract from the first occurrence of 
# Just to the last occurrence of it. These terms can occur across different lines.
# Perform additional transformation to convert ASCII NUL characters, if any, to the newline character.
# \0 representa o caracter nulo
# -z option para  
grep -oz 'Just.*it' sample.txt | tr '\0' '\n'      

