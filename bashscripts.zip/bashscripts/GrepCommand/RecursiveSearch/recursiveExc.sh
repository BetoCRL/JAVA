#!/bin/bash

# Search recursively and display the lines containing ello. Output should not have filename prefix.

grep -rh 'ello'
