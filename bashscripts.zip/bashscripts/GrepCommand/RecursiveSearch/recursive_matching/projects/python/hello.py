def greeting():
    print("Hello, Python!")
greeting()
