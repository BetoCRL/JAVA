#!/bin/sh
sed -i 's/search/replace/g' **/*.txt
