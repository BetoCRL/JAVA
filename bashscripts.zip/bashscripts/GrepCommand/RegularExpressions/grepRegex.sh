#!/bin/bash

# 1º For the input file patterns.txt, extract from ( to the next occurrence of ) 
#unless they contain parentheses characters in between.

    #grep -o '([^()]*)' patterns.txt

# 2º For the input file patterns.txt, match all lines that start with den or end with ly

    #grep -E '^den|ly$' patterns.txt

# 3º For the input file patterns.txt, extract all whole words containing 42 surrounded by word 
#characters on both sides.

    #grep -Eo '+\w42\w+' patterns.txt

# 4º For the input file patterns.txt, match all lines containing car but not as a whole word.

    #grep -E "\Bcar|car\B" patterns.txt

# 5º Count the total number of times the whole words removed or rested or received or replied 
# or refused or retired are present in the patterns.txt file.

    #grep -oEw 're(ceiv|mov|pli|fus|tir|st)ed' patterns.txt | wc -l

# 6º For the input file patterns.txt, match lines starting with s and containing e and t in 
# any order.

    #grep -E "^s[a-zA-Z]*e[a-z]" patterns.txt 


# 7º From the input file patterns.txt, extract all whole lines
# having the same first and last word character.

    #grep -xE '(\w)(.*\1)?' patterns.txt

# 8º For the input file patterns.txt, match all lines containing *[5] literally.

    #grep -E '\*\[5\]'  patterns.txt 
    #grep -F '*[5]' patterns.txt

# 12º For the input file patterns.txt, display all lines starting
# with hand and ending immediately with s or y or le or no further characters.

    #grep -E '^hand(s|y|le)?' patterns.txt
    #grep -E '^hand[sy|le]?' patterns.txt | sort -u

# 13º  For the input files patterns.txt, display matching lines based on the patterns (one per line)
# present in the regex_terms.txt file.

    #grep -f regex_terms.txt patterns.txt

# 14º For the input file patterns.txt, match all lines starting with [5].

    #grep -E '^\[5]' patterns.txt

# 15º From the input file patterns.txt, extract all hexadecimal sequences with a minimum 
#of four characters. Match 0x as an optional prefix, but shouldn't be counted for determining 
#the length. Match the characters case insensitively, and the sequences shouldn't be surrounded 
#by other word characters.

    #grep -iowE '(0x)?[0-9a-f]{4,}' patterns.txt

# 16º From the input file patterns.txt, extract from - till the end of the line,
# provided the characters after the hyphen are all word characters only.

    #grep -oE '\-(\w)*' patterns.txt

# 17º For the input file patterns.txt, count the total number of lines containing e or i followed 
# by l or n and vice versa.

    #grep -oE '[ei].*[ln]|[ln].*[ei]' patterns.txt | wc -l

    #grep -cE '[ei].*[ln]|[ln].*[ei]' patterns.txt

# 18º For the input file patterns.txt, match lines starting with 4 or - or u or sub or care.

    #grep -oE '^(4|-|u|sub|care).*' patterns.txt 

    #grep -E '^([4-u]|sub|care).*' patterns.txt 



#-------------------------------------------------------

#ESPECIAL

# For the input file sample.txt, filter lines containing do and also display the line that comes 
# after such a matching line.

    #grep -A1 -E '(do|also)' ../UsedCommands/sample.txt

# For the input file sample.txt, filter lines containing o followed by zero or more characters 
# and then m or r. Also, display the line that comes before such a matching line.

    #grep -B1 -E 'o\w*[mr]' ../UsedCommands/sample.txt
    
    #grep -B1 'o.*[mr]' ../UsedCommands/sample.txt

# For the input file sample.txt, filter lines containing pay and also display
# the line that comes before and after such a matching line.

    #grep -C1 -E '(pay|also)' ../UsedCommands/sample.txt

#For the input file sample.txt, filter lines containing lie and also display the line
#that comes before and two lines after such a matching line.

#  For the input file sample.txt, filter lines containing are or he as whole words as well
#  as the line that comes before such a matching line. There should be no separator between the
#  groups of matching lines in the output.

    #grep --no-group-separator -B1 -wE "(are|he)" ../UsedCommands/sample.txt

#   For the input file sample.txt, filter lines containing pay or the as well as the 
#   line that comes after/before such a matching line. Show ===== as the separator between 
#   the groups of matching lines in the output.

    #grep --group-separator='=====' -C1 -E '(pay|the)' ../UsedCommands/sample.txt

#   The input file sample.txt has an empty line between group of lines. 
#   Change it to double empty lines between the groups.

    #grep --group-separator='\n' -A0 '.' sample.txt





