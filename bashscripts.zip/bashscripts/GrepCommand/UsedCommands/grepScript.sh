#!/bin/bash

# -w procura por a palavra por completro exemplo do-list e não gado por exemplo
# -i case sensitive
# -n numero da linha que foi encontrado 
# -B ver numero de linhas antes do match EX: -B 4 dá as 4 linhas antes do match
# -A o mesmo que o B mas neste caso é depois do match
# -C Dá as linhas Antes e depois 
# -r  Pesquisa recursiva, com esta opcao, possivel procurar em diretorios e subdiretorios sem regex 
# -l Apresenta que ficheiros contem o match
# -c Apresenta a quantidade de matches dados no ficheiro
# -P Expressões regulares avancadas
# -m numero de linhas limitar
# -f 
# -F trata o que é a expressão regular como uma string fruit[0-9] (não interessa os parentes rectos)
# -H dá display do nome do ficheiro
# -o Apresenta apenas o que deu match e em linhas separadas
# -x Apenas da o match em vez da linha toda

#1º-Display lines containing an from the sample.txt input file.

    #grep "an" sample.txt

#2º-Display lines containing do as a whole word from the sample.txt input file.

    #grep  -w "do" sample.txt

#3º-Display lines from sample.txt that satisfy both of these conditions:
#    *he matched irrespective of case
#    *either World or Hi matched case sensitively
    
    #grep "he" sample.txt | grep -E -i 'World|Hi' sample.txt

#4º-Display lines from code.txt containing fruit[0] literally.

    #grep -wiE 'fruit\[0\]' ../GrepCommand/code.txt

#5º-Display only the first two matching lines containing t from the sample.txt input file.

    #grep -m2 't' ../GrepCommand/sample.txt

#6º-Display only the first three matching lines that do not contain he from the sample.txt 
#input file.

    #grep -v -m3 'he' ../GrepCommand/sample.txt

#7º-Display lines from sample.txt that contain do along with line number prefix.

    #grep -n 'do' ../GrepCommand/sample.txt

#8º-For the input file sample.txt, count the number of times the string he is present, 
#irrespective of case.

    #grep -io 'he' ../GrepCommand/sample.txt | wc -l

#9º-For the input file sample.txt, count the number of empty lines.

    #grep -cxE '[[:space:]]' ../GrepCommand/sample.txt  

#10º-For the input files sample.txt and code.txt, display matching lines based on the 
#search terms (one per line) present in the terms.txt file. 
#Results should be prefixed with the corresponding input filename.

    #grep -Ff terms.txt sample.txt code.txt

#11º-For the input file sample.txt, display lines containing amigo prefixed by
#the input filename as well as the line number.

    #grep -nH "amigo" sample.txt


#12º-For the input files sample.txt and code.txt, display only the filename if it contains apple.

    #grep -L "apple" sample.txt code.txt

#13º-For the input files sample.txt and code.txt, display only whole matching
#lines based on the search terms (one per line) present in the lines.txt file.
#Results should be prefixed with the corresponding input filename as well as the line number.

    #grep -nFf lines.txt sample.txt code.txt

#14º- For the input files sample.txt and code.txt, count the number of lines that do not match 
#any of the search terms (one per line) present in the terms.txt file.

    #grep -vcFf terms.txt sample.txt code.txt

#15º- Count the total number of lines containing banana in the input files 
#sample.txt and code.txt.
    
    #cat sample.txt code.txt | grep -c "banana" 

#16º- Which two conditions are necessary for the output of the grep command to be suitable 
#for the vim -q quickfix mode?