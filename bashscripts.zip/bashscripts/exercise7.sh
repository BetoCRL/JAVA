#!/bin/bash

#Write a shell script that accepts a file or directory name as an argument.
#Have the script report if it is reguler file, a directory, or another type of file.
#If it is a directory, exit with a 1 exit status. If it is some other type of file,
#exit with a 2 exit status.


echo "Insira o nome do ficheiro ou directorio: "
read -r NOME
FIND_ELEMENT=$(find "$HOME" -name "$NOME" -print -quit)
if [ "$FIND_ELEMENT" ]; then 
    if [ -f "$FIND_ELEMENT" ]; then
        echo "É um diretorio, codigo 0"
        exit 0
    elif [ -d "$FIND_ELEMENT" ]; then
        echo "É um diretorio, codigo 1"
        exit 1
    else
        echo "É outro tipo de ficheiro"
        exit 2
    fi
else
    echo "Não foi encontrado nada"
fi  