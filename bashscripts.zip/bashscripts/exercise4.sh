#!/bin/bash

# write a shell script that prompts the user for a name of a file or directory and reports
#if it is a regular file, a directory, or another type of file.
# Also perform an ls command against the file or directory with the long listing option.

echo "Insira o nome do ficheiro ou directorio: "
read -r NOME
FIND_ELEMENT=$(find "$HOME" -name "$NOME" -print -quit)
if [ "$FIND_ELEMENT" ]; then 
    LIST=$(ls -l "$NOME")
    if [ -f "$NOME" ]; then
        printf "É um ficheiro regular\n %i" "$LIST"
    elif [ -d "$NOME" ]; then
        printf "É um diretorio\n %i" "$LIST"
    else
        echo "É outro tipo de ficheiro"
    fi
else
    echo "Não foi encontrado nada"
fi  