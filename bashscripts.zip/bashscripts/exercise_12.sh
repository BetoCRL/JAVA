#!/bin/bash

# Write the script that renames files based on the file extension.  done
#Next,It should ask the user what prefix to prepend to the file name(s).  done
#By default, the prefix should be the current date in YYYY-MM-DD format. done
#If the user simply press enter,the current date will be used. ´
#Otherwise,whatever the user entered will be used as the prefix. 
#Next,it should display the original file name and new name of the file. 
#Finally,it should rename the file.

TODAYS_DATE=$(date +%m-%d-%Y)

printf "Insira o nome do diretorio que prentende renomear os ficheiros: "
read -r NOME_DIRETORIO

printf "\nInsira que tipos de ficheiros pretende alterar (extensão): "
read -r EXTENSAO

CAMINHO_ABSOLUTO=$(find "$HOME" -name "$NOME_DIRETORIO")

echo "$CAMINHO_ABSOLUTO"

if [ -d "$CAMINHO_ABSOLUTO" ]; then
    FICHEIROS=$(find "$CAMINHO_ABSOLUTO" -type f -name "*.$EXTENSAO")
    for FICH in $FICHEIROS
    do  
        FILE_NAME=$(basename "$FICH")
        printf "\nInsira o prefixo que pretende inserir para o ficheiro %s: " "$FILE_NAME"
        read -r PREFIX
        if [ -z "$PREFIX" ]; then
            PREFIX="$TODAYS_DATE"
        fi
        NEW_PATH_FILE="$CAMINHO_ABSOLUTO/$PREFIX.$EXTENSAO"
        NEW_FILE_NAME=$(basename "$NEW_PATH_FILE")
        mv "$FICH" "$NEW_PATH_FILE"
        printf "\nNome ficheiro antigo: %s\nNome do novo ficheiro: %s" "$FILE_NAME" "$NEW_FILE_NAME"
    done
else
    echo "Caminho de diretorio não encontrado"
fi



