#!/bin/bash
#Exercise_17 - Write the shell script that displays one random number on the screen 
#and also generates a system log message with that random number.Use the “user” facility
#and “info” facility for your messages.

RANDOM_NUMBER="This is a random number: $RANDOM"
echo "$RANDOM_NUMBER"
logger -p user.info "$RANDOM_NUMBER"
