#!/bin/bash

#Modify the previous script to that it accepts the file or directory name
#as an argument instead of prompting the user to enter it.'

FIND_ELEMENT=$(find "$HOME" -name "$1" -print -quit)
if [ "$FIND_ELEMENT" ]; then 
    LIST=$(ls -l "$1")
    if [ -f "$FIND_ELEMENT" ]; then
        printf "É um ficheiro regular\n %i" "$LIST"
    elif [ -d NOME ]; then
        printf "É um diretorio\n %i" "$LIST"
    else
        echo "É outro tipo de ficheiro"
    fi
else
    echo "Não foi encontrado nada"
fi  