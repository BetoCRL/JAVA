#!/bin/bash

#Write the shell script that renames all files in the current directory 
#that end in “.jpg” to begin with today’s date in the following format: YYYY-MM-DD. 
#For example, if a picture of my cat was in the current directory and today was October
#31,2016 it would change name from “mycat.jpg” to “2016–10–31-mycat.jpg”.


CAMINHO_IMAGENS=/c/Users/andradefr/Desktop/bashscripts/Imagens/

LIST_IMGS=$(find $CAMINHO_IMAGENS -type f \( -iname \*.jfif -o -iname \*.png \))
TODAYS_DATE=$(date +%m-%d-%Y)
for img in $LIST_IMGS
do
    NAME_OF_IMG=$(basename "$img")
    mv "$img" "$CAMINHO_IMAGENS/$TODAYS_DATE-$NAME_OF_IMG"
done
