#!/bin/bash
#Write a Shell Bash Script for evaluate the status of a file/directory.
#Write a Shell Script for output a specified directory’s size.

echo "Introduza um path de um diretorio ou de um ficheiro: " 
read -r PATH_T 

if [ -d "$PATH_T" ] || [ -f "$PATH_T" ]; then 
    TAMANHO_PATH=$(du -sh "$PATH_T" | awk '{print $1}')
    printf "\nO tamanho do diretorio: %s\n" "$TAMANHO_PATH" 
else 
    echo "Caminho não existe"
fi
