#!/bin/bash
#Modify the previous script to accept an unlimited number of files and directories as arguments.

for var in "$@"
do
    FIND_ELEMENT=$(find "$HOME" -name "$var" -print -quit)
    if [ "$FIND_ELEMENT" ]; then 
        LIST=$(ls -l "$FIND_ELEMENT")
        if [ -f "$FIND_ELEMENT" ]; then
            printf "\n%s É um ficheiro regular\n%s\n" "$var" "$LIST"
        elif [ -d "$FIND_ELEMENT" ]; then
            printf "\n%s É um diretorio\n%s\n" "$var" "$LIST"
        else
            printf "%s É outro tipo de ficheiro\n" "$var"
        fi
    else
        echo "Não foi encontrado nada"
    fi   
done


