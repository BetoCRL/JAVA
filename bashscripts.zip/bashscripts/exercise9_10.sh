#!/bin/bash
#Write a shell script that consists of a function that displays the number of files in the present
#working directory. Name this function “file_count” and call it in your script.
#If you use variable in your function, remember to make it a local variable.


function file_count () {
  for file_m in *  
   do 
        if [ -f "$file_m" ]; then
            ((COUNT+=1))
        fi
   done 
  echo "Tem $COUNT ficheiros no currente diretorio"
}


#file_count


#Modify the script from the previous exercise. Make the “file_count” function accept 
#a directory as an argument. Next, have the function display the name of the directory 
#followed by a colon. Finally display the number of files to the screen on the next line. 
#Call the function three times. First on the “/etc” directory, next on the “/var” directory and
# finally on the “/usr/bin” directory.

timeout() {

    time=$1

    # start the command in a subshell to avoid problem with pipes
    # (spawn accepts one command)
    command="/bin/sh -c \"$2\""

    expect -c "set echo \"-noecho\"; set timeout $time; spawn -noecho $command; expect timeout { exit 1 } eof { exit 0 }"    

    if [ $? = 1 ] ; then
        echo "Timeout after ${time} seconds"
    fi

}


#FALTA POR O TIMEOUT
function file_count_feito()
 { 
   FIND_ELEMENT=$(find / -path "$1" -print -quit)
    if [ -d "$FIND_ELEMENT" ]; then
      NOME_DIRETORIO=$(basename "$FIND_ELEMENT")
    fi
    NUMBER_OF_FILE=$(find "$FIND_ELEMENT" -type f -not -path '*/\.*' | wc -l)
    if [ -n "$NUMBER_OF_FILE" ]; then
      printf "\nNome do directorio %s,\nTem %i ficheiros no diretorio" "$NOME_DIRETORIO" "$NUMBER_OF_FILE"
    else 
      echo "Ficheiro $NOME_DIRETORIO não encontrado"
    fi
 }


 

 file_count_feito /etc
 file_count_feito /usr/bin
 file_count_feito /var
